/*
Navicat MySQL Data Transfer

Source Server         : 我的新服务器
Source Server Version : 50565
Source Host           : localhost:3306
Source Database       : shopdb

Target Server Type    : MYSQL
Target Server Version : 50565
File Encoding         : 65001

Date: 2020-06-21 23:29:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `goods`
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `typeid` int(10) unsigned NOT NULL,
  `price` double(6,2) unsigned NOT NULL,
  `total` int(10) unsigned NOT NULL,
  `pic` varchar(32) NOT NULL,
  `note` text,
  `addtime` int(10) unsigned NOT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES (
			'1', 
			'海南金煌芒', 
			'2', 
			'29.90', 
			'200',
			 '2.png',
			 '净含量：4.5斤\r\n\r\n产地: 中国海南省\r\n\r\n水果种类:芒果\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'2', 
			'进口金枕榴莲', 
			'8', 
			'99.90', 
			'50',
			 '8.png',
			 '净含量：3-4斤\r\n\r\n产地: 泰国\r\n\r\n水果种类:榴莲\r\n\r\n包装方式: 盒装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'3', 
			'增城桂味', 
			'6', 
			'59.90', 
			'100',
			 '6.png',
			 '净含量：3斤\r\n\r\n产地: 中国广东省\r\n\r\n水果种类:荔枝\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'4', 
			'大理阳光玫瑰青提', 
			'4', 
			'49.90', 
			'100',
			 '4.png',
			 '净含量：3斤\r\n\r\n产地: 中国云南省\r\n\r\n水果种类:葡萄\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'5', 
			'客家沃柑', 
			'5', 
			'29.90', 
			'300',
			 '5.png',
			 '净含量：10斤\r\n\r\n产地: 中国广东省\r\n\r\n水果种类:橘子\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'6', 
			'泰国山竹', 
			'9', 
			'39.90', 
			'100',
			 '9.png',
			 '净含量：2斤\r\n\r\n产地: 泰国\r\n\r\n水果种类:山竹\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'7', 
			'烟台红富士15个装', 
			'11', 
			'29.90', 
			'200',
			 '11.png',
			 '净含量：3斤\r\n\r\n产地: 中国山东省\r\n\r\n水果种类:苹果\r\n\r\n包装方式: 盒装\r\n\r\n保质期：15天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'8', 
			'金都一号红心火龙果', 
			'13', 
			'59.90', 
			'200',
			 '13.png',
			 '净含量：5斤\r\n\r\n产地: 中国广西省\r\n\r\n水果种类:火龙果\r\n\r\n包装方式: 盒装\r\n\r\n保质期：15天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'9', 
			'海南妃子笑', 
			'6', 
			'39.90', 
			'200',
			 '6-2.png',
			 '净含量：2斤\r\n\r\n产地: 中国海南省\r\n\r\n水果种类:荔枝\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'10', 
			'无锡阳山水蜜桃9个装', 
			'3', 
			'109.90', 
			'300',
			 '3.png',
			 '净含量：2斤\r\n\r\n产地: 中国江苏省\r\n\r\n水果种类:桃子\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'11', 
			'天水花牛苹果', 
			'11', 
			'39.90', 
			'200',
			 '11-2.png',
			 '净含量：3斤\r\n\r\n产地: 中国甘肃省\r\n\r\n水果种类:苹果\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

INSERT INTO `goods` VALUES (
			'12', 
			'广东苹果蕉', 
			'10', 
			'39.90', 
			'200',
			 '10.png',
			 '净含量：5斤\r\n\r\n产地: 中国广东省\r\n\r\n水果种类:香蕉\r\n\r\n包装方式: 散装\r\n\r\n保质期：7天', 
			'2023-06-08 08:56:21', null);

-- ----------------------------
-- Table structure for `tb_order`
-- ----------------------------
DROP TABLE IF EXISTS `tb_order`;
CREATE TABLE `tb_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `goods_id` int(10) DEFAULT NULL,
  `order_sn` varchar(50) DEFAULT NULL COMMENT '订单号',
  `order_money` float(10,2) DEFAULT NULL COMMENT '订单金额',
  `consignee` varchar(20) DEFAULT NULL COMMENT '收货人',
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL COMMENT '收货地址',
  `createtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_order
-- ----------------------------
INSERT INTO `tb_order` VALUES ('1', '2', '7', '2023062038683', '29.90', '温垚', '18259000000', '广东白云学院', '2023-06-20 10:23:31', null);

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '96e79218965eb72c92a549dd5a330112', '2023-06-05 10:54:47', null);
INSERT INTO `user` VALUES ('2', '温垚', '123456', '2023-06-05 11:38:04', null);
INSERT INTO `user` VALUES ('3', '邵嘉俊', '123456', '2023-06-08 08:56:00', '2023-06-08 08:56:21');
INSERT INTO `user` VALUES ('4', '吕冰奇', '123456', '2023-06-09 00:35:18', null);
