<?php 
	session_start();
?>
<div class="shop_header">
    	<h1 class="shop_title" style="color:white;">711水果商城</h1>
    	<div class="search_bar">
    		<form action="<?php echo $_SERVER['PHP_SELF'];?>">
    			<input type="text" name="searchword" autocomplete="off" value="<?php if(isset($_GET['searchword'])) echo $_GET['searchword'];?>"><button>搜索</button>
    		</form>
    	</div>
    	<div class="login_register_bar">
    		<?php 
    			if(isset($_SESSION) && isset($_SESSION['userId']) && $_SESSION['userId']){
    		?>
    		<?php 
    				if($_SESSION['adminId']){
						echo "用户:".$_SESSION['userName']."";
    		?>
		
		
    		<a href="admin.php"><button>管理</button></a>
		|
    		<a href="loginAction.php?act=logout"><button>退出</button></a>
	
    		<?php 
    				}else{
						echo "用户:".$_SESSION['userName']."";
    		?>

    		<a href="updatePwd.php"><button>密码</button></a>
		|
    		<a href="loginAction.php?act=logout"><button>退出</button></a>
    		<?php 
    				}
    		?>
    		<?php ?>
    			
    		<?php 
    			}else{
    		?>
    			<a href="login.php"><button>登录</button></a>
    			|
    			<a href="register.php"><button>注册</button></a>
    		<?php 
    			}
    		?>
    		
    		
    	</div>
    </div>
<script>
	function deleteInfo() {
            alert("火龙果今日特惠！！！");
	}
</script>
    <div class="shop_nav">
    	<ul>
    		<li><a href="index.php">首页</a></li>
    		<li><a href="myOrderList.php">我的订单</a></li>
		<li><a href="" onclick="return deleteInfo()">公告</a></li>
    		<?php 
    			if(isset($_SESSION) && isset($_SESSION['userId']) && $_SESSION['userId']){
    		?>
		
    		<?php 
    			}
    		?>
    	</ul>
    </div>