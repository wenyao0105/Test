<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <title>登录页面</title>
    <link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
    <script type="text/javascript" src="script/check.js"></script>
<style>
            	body {
                	background-image: url(uploads/bgimg.jpg);
		background-size: 100% 130% ;
            	}
</style>
</head>

<body class="shop_body">
	<?php 
		include 'front-top.php';
	?>
    <div class="formContain">
    	<form action="loginAction.php?act=login" method="post" onsubmit="return validate_form(this)">
    		<h2 class="frm_title">用户登录</h2>
    		<p><span>账号</span><input type="text" name="username" autocomplete="off" class="txt-inp"></p>
    		<p><span>密码</span><input type="password" name="password" class="txt-inp"></p>
		<p><span>验证码</span><input type="text" name="captcha" height="30px">
		<img src="image_captcha.php" onclick="this.src='image_captcha.php?'+new Date().getTime();"
			width="90" height="50">
		</p>
    		<p class="txt_center"><input type="submit" value="登录" class="frm-btn"></p>
    	</form>
    </div>
    <script type="text/javascript">
    function validate_form(thisform){
    	with (thisform){
	      if (validate_required(username,"请输入账号")==false){
		      	username.focus();
		      	return false;
		  }
	      if (validate_required(password,"请输入密码")==false){
	    		 password.focus();
	    		 return false;
	    }
	      if (validate_required(password,"请输入验证码")==false){
	    		 captcha.focus();
	    		 return false;
	    }
	  }
    }
    </script>
</body>

</html>