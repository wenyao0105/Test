<?php 
session_start();// 开启session
require("functions.php");// 引入函数
checkLogined();// 判断管理员是否登录
?>
<!doctype html>
<html>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<title>后台管理</title>
		<link rel="stylesheet" href="css/mystyle.css" type="text/css"/>
<style>
            	body {
                	background-image: url(uploads/bgimg.jpg);
		background-size: 100% 120% ;
            	}
</style>
	</head>
	<body>
		<div class="admin_head">
			<h1 style="text-align: center">后台管理系统</h1>
		</div>
		<div class="admin_content">
			<!--左侧列表-->
        	<div class="menu">
        		<div class="cont">
        			<div class="title"><h2>管理员</h2></div>
        			<ul class="mList">
        				<li>
	                        <h3><span>+</span>用户管理</h3>
	                        <dl>
	                        	<dd><a href="admin_user/addUser.php" target="mainFrame"><button>添加用户</a></button></dd>
	                            <dd><a href="admin_user/userList.php" target="mainFrame"><button>用户列表</a></button></dd>
	                        </dl>
                    	</li>
        				<li>
	                        <h3><span>+</span>商品管理</h3>
	                        <dl>
	                        	<dd><a href="admin_goods/addGoods.php" target="mainFrame"><button>添加商品</a></button></dd>
	                            <dd><a href="admin_goods/goodsList.php" target="mainFrame"><button>商品列表</a></button></dd>
	                        </dl>
                    	</li>
                    	<li>
	                        <h3><span>+</span>订单管理</h3>
	                        <dl>
	                            <dd><a href="admin_order/orderList.php" target="mainFrame"><button>订单列表</button></a></dd>
	                        </dl>
                    	</li>
                    	<li>
	                        <h3><span>+</span>系统管理</h3>
	                        <dl>
	                            <dd><a href="index.php"><button>返回首页</button></a></dd>
	                        </dl>
	                        <dl>
	                            <dd><a href="loginAction.php?act=logout"><button>退出登录</button></a></dd>
	                        </dl>
                    	</li>
        			</ul>
        		</div>
        	</div>
		
			<div class="main">
	            <!--右侧内容-->
	            <div class="cont">
	                <!-- <div class="title">后台管理</div> -->
	      	 		<!-- 嵌套网页开始 -->         
	                <iframe src="adminMain.php"  frameborder="0" name="mainFrame" width="100%" height="800"></iframe>
	                <!-- 嵌套网页结束 -->   
	            </div>
        	</div>
        	
		</div>
			
		
	</body>
</html>